# Attendance Management System in PHP 

> YOU MUST HAVE A BASIC UNDERSTANDING OF HOW TO RUN PHP PROJECTS

### Steps to use:
- Download the zip
- In XAMPP phpMyAdmin import attendance.sql file
- Default ID and PASSWORD is 'admin'
- You are good to go!


Do not use UNETHICALLY
