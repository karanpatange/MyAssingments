<?php

$dbhost = 'localhost';
$dbname = 'attendance';
$dbuser = 'root';
$dbpassword = '';


$dsn = "mysql:host=$dbhost;dbname=$dbname";
?>